module.exports = {
    dev: {
        DESCN:'开发环境',
        API_BASE_URL:'http://localhost:8160',
    },
    prod: {
        DESCN:'线上环境',
	    API_BASE_URL:'https://',
    }
}

