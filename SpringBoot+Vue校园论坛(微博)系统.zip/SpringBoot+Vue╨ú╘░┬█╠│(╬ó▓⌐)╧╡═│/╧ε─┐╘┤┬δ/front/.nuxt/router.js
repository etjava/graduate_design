import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _478c523a = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _140c322e = () => interopDefault(import('..\\pages\\resetPwd.vue' /* webpackChunkName: "pages/resetPwd" */))
const _d0c45824 = () => interopDefault(import('..\\pages\\userlogin.vue' /* webpackChunkName: "pages/userlogin" */))
const _b49c439a = () => interopDefault(import('..\\pages\\wxamp.vue' /* webpackChunkName: "pages/wxamp" */))
const _4c97bdee = () => interopDefault(import('..\\pages\\User\\management.vue' /* webpackChunkName: "pages/User/management" */))
const _52f1f4b4 = () => interopDefault(import('..\\pages\\User\\profile\\index.vue' /* webpackChunkName: "pages/User/profile/index" */))
const _641f7718 = () => interopDefault(import('..\\pages\\User\\publish.vue' /* webpackChunkName: "pages/User/publish" */))
const _2beac47c = () => interopDefault(import('..\\pages\\User\\profile\\resetPwd.vue' /* webpackChunkName: "pages/User/profile/resetPwd" */))
const _7f961cdc = () => interopDefault(import('..\\pages\\User\\profile\\userAvatar.vue' /* webpackChunkName: "pages/User/profile/userAvatar" */))
const _503e941a = () => interopDefault(import('..\\pages\\User\\profile\\userEmail.vue' /* webpackChunkName: "pages/User/profile/userEmail" */))
const _36b7f6a7 = () => interopDefault(import('..\\pages\\User\\profile\\userInfo.vue' /* webpackChunkName: "pages/User/profile/userInfo" */))
const _f047d48c = () => interopDefault(import('..\\pages\\c\\_contentId\\index.vue' /* webpackChunkName: "pages/c/_contentId/index" */))
const _176c7dc2 = () => interopDefault(import('..\\pages\\email-validate\\_uuid\\index.vue' /* webpackChunkName: "pages/email-validate/_uuid/index" */))
const _0ca4b442 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/register",
    component: _478c523a,
    name: "register"
  }, {
    path: "/resetPwd",
    component: _140c322e,
    name: "resetPwd"
  }, {
    path: "/userlogin",
    component: _d0c45824,
    name: "userlogin"
  }, {
    path: "/wxamp",
    component: _b49c439a,
    name: "wxamp"
  }, {
    path: "/User/management",
    component: _4c97bdee,
    name: "User-management"
  }, {
    path: "/User/profile",
    component: _52f1f4b4,
    name: "User-profile"
  }, {
    path: "/User/publish",
    component: _641f7718,
    name: "User-publish"
  }, {
    path: "/User/profile/resetPwd",
    component: _2beac47c,
    name: "User-profile-resetPwd"
  }, {
    path: "/User/profile/userAvatar",
    component: _7f961cdc,
    name: "User-profile-userAvatar"
  }, {
    path: "/User/profile/userEmail",
    component: _503e941a,
    name: "User-profile-userEmail"
  }, {
    path: "/User/profile/userInfo",
    component: _36b7f6a7,
    name: "User-profile-userInfo"
  }, {
    path: "/c/:contentId",
    component: _f047d48c,
    name: "c-contentId"
  }, {
    path: "/email-validate/:uuid",
    component: _176c7dc2,
    name: "email-validate-uuid"
  }, {
    path: "/",
    component: _0ca4b442,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
