// import Vue from "vue";
// import { VueCropper } from "vue-cropper";
// Vue.use(VueCropper)


// Vue =  require('vue')
// if(process.browser) {
//   vueCropper = require('vue-cropper')
//   Vue.use(vueCropper.default)
// }

import Vue from 'vue'
import { VueCropper } from "vue-cropper"
Vue.component('VueCropper', VueCropper)
