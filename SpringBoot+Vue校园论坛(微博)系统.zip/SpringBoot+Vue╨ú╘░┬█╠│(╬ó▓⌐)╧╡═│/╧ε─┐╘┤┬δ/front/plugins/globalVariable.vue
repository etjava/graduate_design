<script>
export default {
  data() {
    return {
      //定义全局变量
      userInfoGlobal: {
        userId: "",
        avatar: "",
        email: "",
        nickName: "",
        userName: "",
      },
    };
  },
};
</script>