package com.oddfar.campus.business.domain.vo;


import lombok.Data;

import java.util.ArrayList;

@Data
public class DateAddUserVo {

    private ArrayList<String> addDate;
    private ArrayList<Integer> addNum;

}
